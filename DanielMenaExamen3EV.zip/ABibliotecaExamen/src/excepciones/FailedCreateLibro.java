package excepciones;

/**
 * FailedCreateLibro
 */
public class FailedCreateLibro extends Exception {
    public FailedCreateLibro(String message){
        super(message);

    }
}