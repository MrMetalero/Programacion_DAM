package excepciones;

/**
 * EmpleadoNoEncontradoException
 */
public class LibroNoEncontradoException extends Exception{
    public LibroNoEncontradoException(String message){
        super(message);

    }
}