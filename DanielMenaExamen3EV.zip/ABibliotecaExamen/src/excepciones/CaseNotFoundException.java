package excepciones;

/**
 * CaseNotFoundException
 */
public class CaseNotFoundException extends Exception {
    public CaseNotFoundException(String message){
        super(message);

    }
    
}