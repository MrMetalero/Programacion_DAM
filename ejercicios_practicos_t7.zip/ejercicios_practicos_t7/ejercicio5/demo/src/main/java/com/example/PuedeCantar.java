package com.example;

public interface PuedeCantar {
    public String cantar();
}
