package com.example;

public class Gallo implements PuedeCantar {
    
    public String cantar(){
        return "COCK COCK COCK COCK";

    }

}
