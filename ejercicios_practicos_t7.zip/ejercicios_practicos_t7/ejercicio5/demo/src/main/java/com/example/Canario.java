package com.example;

public class Canario implements PuedeCantar {
    
    public String cantar(){
        return "WKGWKGKWG KGWKGKWKGW";

    }
}
