package com.example;

public class Persona implements PuedeCantar {
    

    public String cantar(){

        return "Do re mi fa sol";

    }

}
