package com.example;

public class Fresco extends Producto {
    

    public Fresco(String fechaCaducidad,Integer numeroLote,String fechaEnv,String paisOrig){
        super(fechaCaducidad, numeroLote, fechaCaducidad, fechaCaducidad);




    }


}
