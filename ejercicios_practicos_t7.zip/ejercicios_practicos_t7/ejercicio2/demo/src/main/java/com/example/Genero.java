package com.example;

public enum Genero {
    rock, pop, country, blues, jazz, disco

}
