package com.example;

public class Main {
    public static void main(String[] args) {
    

        Empleado empl1 = new Empleado();
        Encargado enca1 = new Encargado();

        System.out.println(empl1.getSueldo());
        System.out.println(enca1.getSueldo());

    }
}