package com.example;

public class Empleado {
    
    private int sueldo = 1200;





    public int getSueldo() {
        return sueldo;
    }

}
