package com.example;

public class Main {
    public static void main(String[] args) {
        
        final String s1 = new String("Hola");
        String s2 = new String("Mundo");
        s1= s1+s2;

        //no funciona porque es final

    }
}