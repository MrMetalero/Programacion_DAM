package com.example;

public class Triangulo extends Forma {
    
    @Override
    public String identidad() {
        // TODO Auto-generated method stub
        return "Triangulo";
    }

}
