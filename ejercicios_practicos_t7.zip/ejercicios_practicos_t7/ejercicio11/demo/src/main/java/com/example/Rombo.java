package com.example;

public class Rombo extends Forma {
    
    @Override
    public String identidad() {
        // TODO Auto-generated method stub
        return "Rombo";
    }


}
