package com.example;

public class Cuadrado extends Forma {
    

    @Override
    public String identidad() {
        // TODO Auto-generated method stub
        return "Cuadrado";
    }
}
