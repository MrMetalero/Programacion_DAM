package com.example;

import java.lang.reflect.Array;
import java.util.ArrayList;

public abstract class Forma {
    String tipoObjeto;




    public String toString(){

        return identidad();

    }


    public String identidad(){
      


        return  "";
        

    }

}
