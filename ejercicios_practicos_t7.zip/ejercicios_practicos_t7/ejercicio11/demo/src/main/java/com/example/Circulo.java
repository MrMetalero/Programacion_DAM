package com.example;

public class Circulo extends Forma {
    
    @Override
    public String identidad() {
        // TODO Auto-generated method stub
        return "Circulo";
    }

}
