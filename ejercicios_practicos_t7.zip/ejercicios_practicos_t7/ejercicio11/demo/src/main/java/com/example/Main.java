package com.example;

public class Main {
    public static void main(String[] args) {
       
        Circulo cir1 = new Circulo();
        Cuadrado cuad = new Cuadrado();
        Rombo romb = new Rombo();
        Triangulo triangulo = new Triangulo();

        System.out.println(cir1.toString());
        System.out.println(cuad.toString());
        System.out.println(romb.toString());
        System.out.println(triangulo.toString());


        
    }
}