package com.example;

public class Main {
    public static void main(String[] args) {

        System.out.println("Si se puede implementar sus métodos utilizando override y además se puede heredar la clase aunque sea abstracta. Porque lo he comprobado científicamente :)");


    }





}