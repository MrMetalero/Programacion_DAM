package com.example;

public class HeredadoVehiculo extends Vehiculo {

    @Override
    public int getVelocidadActual() {
        int velocidad = 0;
        return  velocidad;
    }
    


    

}
