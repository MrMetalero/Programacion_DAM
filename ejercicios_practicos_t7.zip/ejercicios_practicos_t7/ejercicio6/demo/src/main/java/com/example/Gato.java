package com.example;

public class Gato extends Felino {
    





    
}
