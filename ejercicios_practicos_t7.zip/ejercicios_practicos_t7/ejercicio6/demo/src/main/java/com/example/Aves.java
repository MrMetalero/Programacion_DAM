package com.example;

public class Aves implements PuedeCaminar {
    
    public String caminar(){
        return "caminando...";

    }

}
