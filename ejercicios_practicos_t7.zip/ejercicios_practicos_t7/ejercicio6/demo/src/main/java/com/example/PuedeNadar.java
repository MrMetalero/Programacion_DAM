package com.example;

public interface PuedeNadar {
    
    public String nadar();

}
