package com.example;

public class Murcielago extends Mamifero implements PuedeVolar {
    
    public String volar(){
        return "volando...";

    }


}
