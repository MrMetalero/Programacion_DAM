package com.example;

public class Avestruz extends Aves {
    

    
}
