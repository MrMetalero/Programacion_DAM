package com.example;

public class Tigre extends Felino {
    
}
