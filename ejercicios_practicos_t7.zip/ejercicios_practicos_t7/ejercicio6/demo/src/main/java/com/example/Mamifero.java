package com.example;

public class Mamifero implements PuedeCaminar {
    
    public String caminar(){


        return "Camina...";
    }




}
