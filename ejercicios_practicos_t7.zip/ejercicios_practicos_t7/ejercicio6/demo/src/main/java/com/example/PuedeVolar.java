package com.example;

public interface PuedeVolar {
    

    public String volar();
}
