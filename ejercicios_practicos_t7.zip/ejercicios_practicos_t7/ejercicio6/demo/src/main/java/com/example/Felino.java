package com.example;

public class Felino extends Mamifero implements PuedeNadar {
    
    public String nadar(){
        return "nadando...";

    }

}
