package com.example;

public interface PuedeCaminar {
    
    public String caminar();

}
