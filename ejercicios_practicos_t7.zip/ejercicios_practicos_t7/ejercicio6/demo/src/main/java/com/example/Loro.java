package com.example;

public class Loro extends Aves implements PuedeVolar {
    
    public String volar(){
        return "volando...";


    }

}
