package com.example;

public interface Prestable {
    
    public void prestar();
    public void devolver();
    public void prestado();




}
