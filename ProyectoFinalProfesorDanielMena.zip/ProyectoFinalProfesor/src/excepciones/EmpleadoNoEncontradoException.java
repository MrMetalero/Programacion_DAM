package excepciones;

/**
 * EmpleadoNoEncontradoException
 */
public class EmpleadoNoEncontradoException extends Exception{
    public EmpleadoNoEncontradoException(String message){
        super(message);

    }
}