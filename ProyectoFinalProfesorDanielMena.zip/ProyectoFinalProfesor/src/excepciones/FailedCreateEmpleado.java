package excepciones;

/**
 * FailedCreateEmpleado
 */
public class FailedCreateEmpleado extends Exception {
    public FailedCreateEmpleado(String message){
        super(message);

    }
}