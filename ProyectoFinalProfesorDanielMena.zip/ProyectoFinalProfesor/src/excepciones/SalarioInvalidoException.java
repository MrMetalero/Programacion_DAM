package excepciones;

/**
 * SalarioInvalidoException
 */
public class SalarioInvalidoException extends Exception {

    public SalarioInvalidoException(String message){
        super(message);

    }
}