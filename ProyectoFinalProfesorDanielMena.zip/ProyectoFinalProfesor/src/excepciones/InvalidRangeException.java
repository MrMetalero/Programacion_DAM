package excepciones;
class InvalidRangeException extends Exception {
    
    public InvalidRangeException(String message){
        super(message);

    }


}


